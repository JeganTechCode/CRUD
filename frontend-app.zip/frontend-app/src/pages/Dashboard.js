import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/Dashboard.css'; // Import the CSS file for styling

const Dashboard = () => {
    
  return (
    <div>
      
      <div className="dashboard-content">
        <h2>Welcome to the Dashboard</h2>
        {/* Dashboard content goes here */}
      </div>
    </div>
  );
};

export default Dashboard;
