import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Welcome to the Home Page</h2>
      {/* Add home page content here */}
    </div>
  );
};

export default Home;
