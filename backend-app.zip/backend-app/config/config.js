module.exports = {
    dbName: "CRUD",
    mongodburi: '',
}